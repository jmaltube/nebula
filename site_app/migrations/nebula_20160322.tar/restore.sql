--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.site_app_usuario DROP CONSTRAINT site_app_usuario_lista_id_6059ea34_fk_bienes_app_lista_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id;
ALTER TABLE ONLY public.bienes_app_listayclasificador DROP CONSTRAINT bienes_app_listayclasi_lista_id_b0a9b3b2_fk_bienes_app_lista_id;
ALTER TABLE ONLY public.bienes_app_listaybien DROP CONSTRAINT bienes_app_listaybien_lista_id_3f078a8e_fk_bienes_app_lista_id;
ALTER TABLE ONLY public.bienes_app_listaybien DROP CONSTRAINT bienes_app_listaybien_bien_id_c7c32269_fk_bienes_app_bien_id;
ALTER TABLE ONLY public.bienes_app_compra DROP CONSTRAINT bienes_app_compra_bien_id_a6c6ed52_fk_bienes_app_bien_id;
ALTER TABLE ONLY public.bienes_app_compra DROP CONSTRAINT bienes_app_com_proveedor_id_7225fc9d_fk_bienes_app_proveedor_id;
ALTER TABLE ONLY public.bienes_app_bien DROP CONSTRAINT bienes_app_bien_marca_id_6408d93f_fk_bienes_app_marca_id;
ALTER TABLE ONLY public.bienes_app_bien DROP CONSTRAINT bienes_a_clasificador_id_ca358e99_fk_bienes_app_clasificador_id;
ALTER TABLE ONLY public.bienes_app_listayclasificador DROP CONSTRAINT bienes_a_clasificador_id_4bd9a67d_fk_bienes_app_clasificador_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id;
ALTER TABLE ONLY public.bienes_app_bien DROP CONSTRAINT "D8424966d36598a5db901475e5fdab8a";
DROP INDEX public.site_app_usuario_28125e33;
DROP INDEX public.django_session_session_key_c0390e0f_like;
DROP INDEX public.django_session_de54fa62;
DROP INDEX public.django_admin_log_e8701ad4;
DROP INDEX public.django_admin_log_417f1b1c;
DROP INDEX public.bienes_app_listayclasificador_a2353d82;
DROP INDEX public.bienes_app_listayclasificador_28125e33;
DROP INDEX public.bienes_app_listaybien_97d68a42;
DROP INDEX public.bienes_app_listaybien_28125e33;
DROP INDEX public.bienes_app_compra_97d68a42;
DROP INDEX public.bienes_app_compra_7ac33b97;
DROP INDEX public.bienes_app_bien_bbec06df;
DROP INDEX public.bienes_app_bien_a2353d82;
DROP INDEX public.bienes_app_bien_3195fe4a;
DROP INDEX public.auth_user_username_6821ab7c_like;
DROP INDEX public.auth_user_user_permissions_e8701ad4;
DROP INDEX public.auth_user_user_permissions_8373b171;
DROP INDEX public.auth_user_groups_e8701ad4;
DROP INDEX public.auth_user_groups_0e939a4f;
DROP INDEX public.auth_permission_417f1b1c;
DROP INDEX public.auth_group_permissions_8373b171;
DROP INDEX public.auth_group_permissions_0e939a4f;
DROP INDEX public.auth_group_name_a6ea08ec_like;
ALTER TABLE ONLY public.site_app_usuario DROP CONSTRAINT site_app_usuario_pkey;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_76bd3d3b_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.bienes_app_proveedor DROP CONSTRAINT bienes_app_proveedor_pkey;
ALTER TABLE ONLY public.bienes_app_marca DROP CONSTRAINT bienes_app_marca_pkey;
ALTER TABLE ONLY public.bienes_app_listayclasificador DROP CONSTRAINT bienes_app_listayclasificador_pkey;
ALTER TABLE ONLY public.bienes_app_listayclasificador DROP CONSTRAINT bienes_app_listayclasificador_lista_id_0e31dc98_uniq;
ALTER TABLE ONLY public.bienes_app_listaybien DROP CONSTRAINT bienes_app_listaybien_pkey;
ALTER TABLE ONLY public.bienes_app_listaybien DROP CONSTRAINT bienes_app_listaybien_lista_id_dffc719d_uniq;
ALTER TABLE ONLY public.bienes_app_lista DROP CONSTRAINT bienes_app_lista_pkey;
ALTER TABLE ONLY public.bienes_app_compra DROP CONSTRAINT bienes_app_compra_proveedor_id_014e5d6a_uniq;
ALTER TABLE ONLY public.bienes_app_compra DROP CONSTRAINT bienes_app_compra_pkey;
ALTER TABLE ONLY public.bienes_app_clasificador DROP CONSTRAINT bienes_app_clasificador_pkey;
ALTER TABLE ONLY public.bienes_app_bien DROP CONSTRAINT bienes_app_bien_pkey;
ALTER TABLE ONLY public.bienes_app_abastecimiento DROP CONSTRAINT bienes_app_abastecimiento_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_14a6b632_uniq;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_94350c0c_uniq;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_01ab375a_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE public.site_app_usuario ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bienes_app_proveedor ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bienes_app_marca ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bienes_app_listayclasificador ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bienes_app_listaybien ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bienes_app_lista ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bienes_app_compra ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bienes_app_clasificador ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bienes_app_bien ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bienes_app_abastecimiento ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.site_app_usuario_id_seq;
DROP TABLE public.site_app_usuario;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.bienes_app_proveedor_id_seq;
DROP TABLE public.bienes_app_proveedor;
DROP SEQUENCE public.bienes_app_marca_id_seq;
DROP TABLE public.bienes_app_marca;
DROP SEQUENCE public.bienes_app_listayclasificador_id_seq;
DROP TABLE public.bienes_app_listayclasificador;
DROP SEQUENCE public.bienes_app_listaybien_id_seq;
DROP TABLE public.bienes_app_listaybien;
DROP SEQUENCE public.bienes_app_lista_id_seq;
DROP TABLE public.bienes_app_lista;
DROP SEQUENCE public.bienes_app_compra_id_seq;
DROP TABLE public.bienes_app_compra;
DROP SEQUENCE public.bienes_app_clasificador_id_seq;
DROP TABLE public.bienes_app_clasificador;
DROP SEQUENCE public.bienes_app_bien_id_seq;
DROP TABLE public.bienes_app_bien;
DROP SEQUENCE public.bienes_app_abastecimiento_id_seq;
DROP TABLE public.bienes_app_abastecimiento;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO nebula;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO nebula;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO nebula;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO nebula;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO nebula;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO nebula;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO nebula;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO nebula;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO nebula;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO nebula;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO nebula;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO nebula;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: bienes_app_abastecimiento; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE bienes_app_abastecimiento (
    id integer NOT NULL,
    denominacion character varying(50) NOT NULL
);


ALTER TABLE public.bienes_app_abastecimiento OWNER TO nebula;

--
-- Name: bienes_app_abastecimiento_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE bienes_app_abastecimiento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bienes_app_abastecimiento_id_seq OWNER TO nebula;

--
-- Name: bienes_app_abastecimiento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE bienes_app_abastecimiento_id_seq OWNED BY bienes_app_abastecimiento.id;


--
-- Name: bienes_app_bien; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE bienes_app_bien (
    id integer NOT NULL,
    codigo character varying(50) NOT NULL,
    denominacion character varying(100) NOT NULL,
    costo numeric(10,2) NOT NULL,
    unidad character varying(5) NOT NULL,
    importado boolean NOT NULL,
    sin_stock boolean NOT NULL,
    bulto numeric(10,2) NOT NULL,
    imagen character varying(100) NOT NULL,
    clasificador_id integer NOT NULL,
    forma_abastecimiento_id integer NOT NULL,
    marca_id integer NOT NULL
);


ALTER TABLE public.bienes_app_bien OWNER TO nebula;

--
-- Name: bienes_app_bien_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE bienes_app_bien_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bienes_app_bien_id_seq OWNER TO nebula;

--
-- Name: bienes_app_bien_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE bienes_app_bien_id_seq OWNED BY bienes_app_bien.id;


--
-- Name: bienes_app_clasificador; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE bienes_app_clasificador (
    id integer NOT NULL,
    denominacion character varying(50) NOT NULL
);


ALTER TABLE public.bienes_app_clasificador OWNER TO nebula;

--
-- Name: bienes_app_clasificador_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE bienes_app_clasificador_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bienes_app_clasificador_id_seq OWNER TO nebula;

--
-- Name: bienes_app_clasificador_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE bienes_app_clasificador_id_seq OWNED BY bienes_app_clasificador.id;


--
-- Name: bienes_app_compra; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE bienes_app_compra (
    id integer NOT NULL,
    base_costeo boolean NOT NULL,
    ultima_fecha date NOT NULL,
    costo1 numeric(10,2) NOT NULL,
    moneda_costo1 character varying(3) NOT NULL,
    plazo_entrega smallint NOT NULL,
    bien_id integer NOT NULL,
    proveedor_id integer NOT NULL,
    CONSTRAINT bienes_app_compra_plazo_entrega_check CHECK ((plazo_entrega >= 0))
);


ALTER TABLE public.bienes_app_compra OWNER TO nebula;

--
-- Name: bienes_app_compra_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE bienes_app_compra_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bienes_app_compra_id_seq OWNER TO nebula;

--
-- Name: bienes_app_compra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE bienes_app_compra_id_seq OWNED BY bienes_app_compra.id;


--
-- Name: bienes_app_lista; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE bienes_app_lista (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    tipo character varying(3) NOT NULL
);


ALTER TABLE public.bienes_app_lista OWNER TO nebula;

--
-- Name: bienes_app_lista_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE bienes_app_lista_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bienes_app_lista_id_seq OWNER TO nebula;

--
-- Name: bienes_app_lista_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE bienes_app_lista_id_seq OWNED BY bienes_app_lista.id;


--
-- Name: bienes_app_listaybien; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE bienes_app_listaybien (
    id integer NOT NULL,
    margen numeric(10,2) NOT NULL,
    visible boolean NOT NULL,
    bien_id integer NOT NULL,
    lista_id integer NOT NULL
);


ALTER TABLE public.bienes_app_listaybien OWNER TO nebula;

--
-- Name: bienes_app_listaybien_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE bienes_app_listaybien_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bienes_app_listaybien_id_seq OWNER TO nebula;

--
-- Name: bienes_app_listaybien_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE bienes_app_listaybien_id_seq OWNED BY bienes_app_listaybien.id;


--
-- Name: bienes_app_listayclasificador; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE bienes_app_listayclasificador (
    id integer NOT NULL,
    margen numeric(10,2) NOT NULL,
    visible boolean NOT NULL,
    clasificador_id integer NOT NULL,
    lista_id integer NOT NULL
);


ALTER TABLE public.bienes_app_listayclasificador OWNER TO nebula;

--
-- Name: bienes_app_listayclasificador_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE bienes_app_listayclasificador_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bienes_app_listayclasificador_id_seq OWNER TO nebula;

--
-- Name: bienes_app_listayclasificador_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE bienes_app_listayclasificador_id_seq OWNED BY bienes_app_listayclasificador.id;


--
-- Name: bienes_app_marca; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE bienes_app_marca (
    id integer NOT NULL,
    denominacion character varying(50) NOT NULL
);


ALTER TABLE public.bienes_app_marca OWNER TO nebula;

--
-- Name: bienes_app_marca_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE bienes_app_marca_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bienes_app_marca_id_seq OWNER TO nebula;

--
-- Name: bienes_app_marca_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE bienes_app_marca_id_seq OWNED BY bienes_app_marca.id;


--
-- Name: bienes_app_proveedor; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE bienes_app_proveedor (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    direccion character varying(100) NOT NULL,
    contacto character varying(50) NOT NULL,
    telefono character varying(50) NOT NULL,
    email character varying(50) NOT NULL
);


ALTER TABLE public.bienes_app_proveedor OWNER TO nebula;

--
-- Name: bienes_app_proveedor_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE bienes_app_proveedor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bienes_app_proveedor_id_seq OWNER TO nebula;

--
-- Name: bienes_app_proveedor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE bienes_app_proveedor_id_seq OWNED BY bienes_app_proveedor.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO nebula;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO nebula;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO nebula;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO nebula;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO nebula;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO nebula;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO nebula;

--
-- Name: site_app_usuario; Type: TABLE; Schema: public; Owner: nebula; Tablespace: 
--

CREATE TABLE site_app_usuario (
    id integer NOT NULL,
    nombre_cuenta character varying(254) NOT NULL,
    nombre_persona character varying(100) NOT NULL,
    password character varying(30) NOT NULL,
    lista_id integer NOT NULL
);


ALTER TABLE public.site_app_usuario OWNER TO nebula;

--
-- Name: site_app_usuario_id_seq; Type: SEQUENCE; Schema: public; Owner: nebula
--

CREATE SEQUENCE site_app_usuario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.site_app_usuario_id_seq OWNER TO nebula;

--
-- Name: site_app_usuario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nebula
--

ALTER SEQUENCE site_app_usuario_id_seq OWNED BY site_app_usuario.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_abastecimiento ALTER COLUMN id SET DEFAULT nextval('bienes_app_abastecimiento_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_bien ALTER COLUMN id SET DEFAULT nextval('bienes_app_bien_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_clasificador ALTER COLUMN id SET DEFAULT nextval('bienes_app_clasificador_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_compra ALTER COLUMN id SET DEFAULT nextval('bienes_app_compra_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_lista ALTER COLUMN id SET DEFAULT nextval('bienes_app_lista_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_listaybien ALTER COLUMN id SET DEFAULT nextval('bienes_app_listaybien_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_listayclasificador ALTER COLUMN id SET DEFAULT nextval('bienes_app_listayclasificador_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_marca ALTER COLUMN id SET DEFAULT nextval('bienes_app_marca_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_proveedor ALTER COLUMN id SET DEFAULT nextval('bienes_app_proveedor_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY site_app_usuario ALTER COLUMN id SET DEFAULT nextval('site_app_usuario_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY auth_group (id, name) FROM stdin;
\.
COPY auth_group (id, name) FROM '$$PATH$$/2213.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/2215.dat';

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/2211.dat';

--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('auth_permission_id_seq', 48, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/2217.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/2219.dat';

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('auth_user_id_seq', 1, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/2221.dat';

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: bienes_app_abastecimiento; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY bienes_app_abastecimiento (id, denominacion) FROM stdin;
\.
COPY bienes_app_abastecimiento (id, denominacion) FROM '$$PATH$$/2225.dat';

--
-- Name: bienes_app_abastecimiento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('bienes_app_abastecimiento_id_seq', 1, true);


--
-- Data for Name: bienes_app_bien; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY bienes_app_bien (id, codigo, denominacion, costo, unidad, importado, sin_stock, bulto, imagen, clasificador_id, forma_abastecimiento_id, marca_id) FROM stdin;
\.
COPY bienes_app_bien (id, codigo, denominacion, costo, unidad, importado, sin_stock, bulto, imagen, clasificador_id, forma_abastecimiento_id, marca_id) FROM '$$PATH$$/2227.dat';

--
-- Name: bienes_app_bien_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('bienes_app_bien_id_seq', 5, true);


--
-- Data for Name: bienes_app_clasificador; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY bienes_app_clasificador (id, denominacion) FROM stdin;
\.
COPY bienes_app_clasificador (id, denominacion) FROM '$$PATH$$/2229.dat';

--
-- Name: bienes_app_clasificador_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('bienes_app_clasificador_id_seq', 3, true);


--
-- Data for Name: bienes_app_compra; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY bienes_app_compra (id, base_costeo, ultima_fecha, costo1, moneda_costo1, plazo_entrega, bien_id, proveedor_id) FROM stdin;
\.
COPY bienes_app_compra (id, base_costeo, ultima_fecha, costo1, moneda_costo1, plazo_entrega, bien_id, proveedor_id) FROM '$$PATH$$/2231.dat';

--
-- Name: bienes_app_compra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('bienes_app_compra_id_seq', 3, true);


--
-- Data for Name: bienes_app_lista; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY bienes_app_lista (id, nombre, tipo) FROM stdin;
\.
COPY bienes_app_lista (id, nombre, tipo) FROM '$$PATH$$/2233.dat';

--
-- Name: bienes_app_lista_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('bienes_app_lista_id_seq', 17, true);


--
-- Data for Name: bienes_app_listaybien; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY bienes_app_listaybien (id, margen, visible, bien_id, lista_id) FROM stdin;
\.
COPY bienes_app_listaybien (id, margen, visible, bien_id, lista_id) FROM '$$PATH$$/2235.dat';

--
-- Name: bienes_app_listaybien_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('bienes_app_listaybien_id_seq', 33, true);


--
-- Data for Name: bienes_app_listayclasificador; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY bienes_app_listayclasificador (id, margen, visible, clasificador_id, lista_id) FROM stdin;
\.
COPY bienes_app_listayclasificador (id, margen, visible, clasificador_id, lista_id) FROM '$$PATH$$/2237.dat';

--
-- Name: bienes_app_listayclasificador_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('bienes_app_listayclasificador_id_seq', 32, true);


--
-- Data for Name: bienes_app_marca; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY bienes_app_marca (id, denominacion) FROM stdin;
\.
COPY bienes_app_marca (id, denominacion) FROM '$$PATH$$/2239.dat';

--
-- Name: bienes_app_marca_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('bienes_app_marca_id_seq', 2, true);


--
-- Data for Name: bienes_app_proveedor; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY bienes_app_proveedor (id, nombre, direccion, contacto, telefono, email) FROM stdin;
\.
COPY bienes_app_proveedor (id, nombre, direccion, contacto, telefono, email) FROM '$$PATH$$/2241.dat';

--
-- Name: bienes_app_proveedor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('bienes_app_proveedor_id_seq', 2, true);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/2223.dat';

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 39, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY django_content_type (id, app_label, model) FROM stdin;
\.
COPY django_content_type (id, app_label, model) FROM '$$PATH$$/2209.dat';

--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('django_content_type_id_seq', 16, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY django_migrations (id, app, name, applied) FROM stdin;
\.
COPY django_migrations (id, app, name, applied) FROM '$$PATH$$/2207.dat';

--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('django_migrations_id_seq', 15, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY django_session (session_key, session_data, expire_date) FROM '$$PATH$$/2242.dat';

--
-- Data for Name: site_app_usuario; Type: TABLE DATA; Schema: public; Owner: nebula
--

COPY site_app_usuario (id, nombre_cuenta, nombre_persona, password, lista_id) FROM stdin;
\.
COPY site_app_usuario (id, nombre_cuenta, nombre_persona, password, lista_id) FROM '$$PATH$$/2244.dat';

--
-- Name: site_app_usuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nebula
--

SELECT pg_catalog.setval('site_app_usuario_id_seq', 1, false);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: bienes_app_abastecimiento_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY bienes_app_abastecimiento
    ADD CONSTRAINT bienes_app_abastecimiento_pkey PRIMARY KEY (id);


--
-- Name: bienes_app_bien_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY bienes_app_bien
    ADD CONSTRAINT bienes_app_bien_pkey PRIMARY KEY (id);


--
-- Name: bienes_app_clasificador_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY bienes_app_clasificador
    ADD CONSTRAINT bienes_app_clasificador_pkey PRIMARY KEY (id);


--
-- Name: bienes_app_compra_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY bienes_app_compra
    ADD CONSTRAINT bienes_app_compra_pkey PRIMARY KEY (id);


--
-- Name: bienes_app_compra_proveedor_id_014e5d6a_uniq; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY bienes_app_compra
    ADD CONSTRAINT bienes_app_compra_proveedor_id_014e5d6a_uniq UNIQUE (proveedor_id, bien_id);


--
-- Name: bienes_app_lista_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY bienes_app_lista
    ADD CONSTRAINT bienes_app_lista_pkey PRIMARY KEY (id);


--
-- Name: bienes_app_listaybien_lista_id_dffc719d_uniq; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY bienes_app_listaybien
    ADD CONSTRAINT bienes_app_listaybien_lista_id_dffc719d_uniq UNIQUE (lista_id, bien_id);


--
-- Name: bienes_app_listaybien_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY bienes_app_listaybien
    ADD CONSTRAINT bienes_app_listaybien_pkey PRIMARY KEY (id);


--
-- Name: bienes_app_listayclasificador_lista_id_0e31dc98_uniq; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY bienes_app_listayclasificador
    ADD CONSTRAINT bienes_app_listayclasificador_lista_id_0e31dc98_uniq UNIQUE (lista_id, clasificador_id);


--
-- Name: bienes_app_listayclasificador_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY bienes_app_listayclasificador
    ADD CONSTRAINT bienes_app_listayclasificador_pkey PRIMARY KEY (id);


--
-- Name: bienes_app_marca_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY bienes_app_marca
    ADD CONSTRAINT bienes_app_marca_pkey PRIMARY KEY (id);


--
-- Name: bienes_app_proveedor_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY bienes_app_proveedor
    ADD CONSTRAINT bienes_app_proveedor_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: site_app_usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: nebula; Tablespace: 
--

ALTER TABLE ONLY site_app_usuario
    ADD CONSTRAINT site_app_usuario_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX auth_group_name_a6ea08ec_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX auth_user_groups_0e939a4f ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX auth_user_groups_e8701ad4 ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_8373b171 ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX auth_user_username_6821ab7c_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: bienes_app_bien_3195fe4a; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX bienes_app_bien_3195fe4a ON bienes_app_bien USING btree (forma_abastecimiento_id);


--
-- Name: bienes_app_bien_a2353d82; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX bienes_app_bien_a2353d82 ON bienes_app_bien USING btree (clasificador_id);


--
-- Name: bienes_app_bien_bbec06df; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX bienes_app_bien_bbec06df ON bienes_app_bien USING btree (marca_id);


--
-- Name: bienes_app_compra_7ac33b97; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX bienes_app_compra_7ac33b97 ON bienes_app_compra USING btree (proveedor_id);


--
-- Name: bienes_app_compra_97d68a42; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX bienes_app_compra_97d68a42 ON bienes_app_compra USING btree (bien_id);


--
-- Name: bienes_app_listaybien_28125e33; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX bienes_app_listaybien_28125e33 ON bienes_app_listaybien USING btree (lista_id);


--
-- Name: bienes_app_listaybien_97d68a42; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX bienes_app_listaybien_97d68a42 ON bienes_app_listaybien USING btree (bien_id);


--
-- Name: bienes_app_listayclasificador_28125e33; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX bienes_app_listayclasificador_28125e33 ON bienes_app_listayclasificador USING btree (lista_id);


--
-- Name: bienes_app_listayclasificador_a2353d82; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX bienes_app_listayclasificador_a2353d82 ON bienes_app_listayclasificador USING btree (clasificador_id);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX django_session_session_key_c0390e0f_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: site_app_usuario_28125e33; Type: INDEX; Schema: public; Owner: nebula; Tablespace: 
--

CREATE INDEX site_app_usuario_28125e33 ON site_app_usuario USING btree (lista_id);


--
-- Name: D8424966d36598a5db901475e5fdab8a; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_bien
    ADD CONSTRAINT "D8424966d36598a5db901475e5fdab8a" FOREIGN KEY (forma_abastecimiento_id) REFERENCES bienes_app_abastecimiento(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bienes_a_clasificador_id_4bd9a67d_fk_bienes_app_clasificador_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_listayclasificador
    ADD CONSTRAINT bienes_a_clasificador_id_4bd9a67d_fk_bienes_app_clasificador_id FOREIGN KEY (clasificador_id) REFERENCES bienes_app_clasificador(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bienes_a_clasificador_id_ca358e99_fk_bienes_app_clasificador_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_bien
    ADD CONSTRAINT bienes_a_clasificador_id_ca358e99_fk_bienes_app_clasificador_id FOREIGN KEY (clasificador_id) REFERENCES bienes_app_clasificador(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bienes_app_bien_marca_id_6408d93f_fk_bienes_app_marca_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_bien
    ADD CONSTRAINT bienes_app_bien_marca_id_6408d93f_fk_bienes_app_marca_id FOREIGN KEY (marca_id) REFERENCES bienes_app_marca(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bienes_app_com_proveedor_id_7225fc9d_fk_bienes_app_proveedor_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_compra
    ADD CONSTRAINT bienes_app_com_proveedor_id_7225fc9d_fk_bienes_app_proveedor_id FOREIGN KEY (proveedor_id) REFERENCES bienes_app_proveedor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bienes_app_compra_bien_id_a6c6ed52_fk_bienes_app_bien_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_compra
    ADD CONSTRAINT bienes_app_compra_bien_id_a6c6ed52_fk_bienes_app_bien_id FOREIGN KEY (bien_id) REFERENCES bienes_app_bien(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bienes_app_listaybien_bien_id_c7c32269_fk_bienes_app_bien_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_listaybien
    ADD CONSTRAINT bienes_app_listaybien_bien_id_c7c32269_fk_bienes_app_bien_id FOREIGN KEY (bien_id) REFERENCES bienes_app_bien(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bienes_app_listaybien_lista_id_3f078a8e_fk_bienes_app_lista_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_listaybien
    ADD CONSTRAINT bienes_app_listaybien_lista_id_3f078a8e_fk_bienes_app_lista_id FOREIGN KEY (lista_id) REFERENCES bienes_app_lista(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bienes_app_listayclasi_lista_id_b0a9b3b2_fk_bienes_app_lista_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY bienes_app_listayclasificador
    ADD CONSTRAINT bienes_app_listayclasi_lista_id_b0a9b3b2_fk_bienes_app_lista_id FOREIGN KEY (lista_id) REFERENCES bienes_app_lista(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_content_type_id_c4bce8eb_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_app_usuario_lista_id_6059ea34_fk_bienes_app_lista_id; Type: FK CONSTRAINT; Schema: public; Owner: nebula
--

ALTER TABLE ONLY site_app_usuario
    ADD CONSTRAINT site_app_usuario_lista_id_6059ea34_fk_bienes_app_lista_id FOREIGN KEY (lista_id) REFERENCES bienes_app_lista(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

